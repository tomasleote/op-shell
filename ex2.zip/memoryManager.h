// MemoryManager.h
#ifndef MEMORY_MANAGER_H
#define MEMORY_MANAGER_H

#include "fifoPageReplacement.h"

typedef struct {
    FIFOPageReplacement* fifo; // Direct reference to FIFOPageReplacement
    int pageFaults;
} MemoryManager;

// Constructor and destructor equivalents
MemoryManager* MemoryManager_create(int frameCount);
void MemoryManager_destroy(MemoryManager* manager);

// Method to simulate page references
void MemoryManager_simulate(MemoryManager* manager, int* pageReferences, int refCount);

#endif // MEMORY_MANAGER_H
