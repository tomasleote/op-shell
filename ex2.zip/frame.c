#include "frame.h"
#include <stdlib.h>

// Function to create a new Frame object
Frame* Frame_create(int pageNumber) {
    Frame* newFrame = (Frame*)malloc(sizeof(Frame));
    if (newFrame == NULL) {
        return NULL; // Failed to allocate memory
    }
    newFrame->pageNumber = pageNumber;
    return newFrame;
}

// Function to destroy a Frame object
void Frame_destroy(Frame* frame) {
    free(frame);
}

// Getter function for the page number
int Frame_getPageNumber(Frame* frame) {
    return frame->pageNumber;
}
