// MemoryManager.c
#include "memoryManager.h"
#include <stdlib.h>
#include <stdio.h>

MemoryManager* MemoryManager_create(int frameCount) {
    MemoryManager* manager = (MemoryManager*)malloc(sizeof(MemoryManager));
    if (manager == NULL) {
        return NULL; // Failed to allocate memory
    }
    manager->fifo = FIFOPageReplacement_create(frameCount);
    if (manager->fifo == NULL) {
        // Failed to create FIFOPageReplacement, clean up and exit
        free(manager);
        return NULL;
    }
    manager->pageFaults = 0;
    return manager;
}

void MemoryManager_destroy(MemoryManager* manager) {
    if (manager != NULL) {
        FIFOPageReplacement_destroy(manager->fifo); // Clean up FIFOPageReplacement
        free(manager); // Free the manager itself
    }
}

void MemoryManager_simulate(MemoryManager* manager, int* pageReferences, int refCount) {
    for (int i = 0; i < refCount; i++) {
        FIFOPageReplacement_processPageReference(manager->fifo, pageReferences[i]);
    }
    manager->pageFaults = FIFOPageReplacement_getPageFaults(manager->fifo);
    printf("%d\n", manager->pageFaults);
}
