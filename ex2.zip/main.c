#include "memoryManager.h"
#include <stdio.h>
#include <stdlib.h>

int main() {
    int frameCount, refCount, pageNumber;
    int* pageReferences;
    int capacity = 100000;
    MemoryManager* manager;

    // Read the number of frames
    scanf("%d", &frameCount);

    // Allocate memory for page references
    pageReferences = (int*)malloc(sizeof(int) * capacity); // Assuming a maximum of 100 references for simplicity
    if (pageReferences == NULL) {
        printf("Failed to allocate memory for page references.\n");
        return -1;
    }

    // Read page references from stdin until EOF or limit is reached
    refCount = 0;
    while (scanf("%d", &pageNumber) == 1) {
        if (refCount >= capacity) {
            // Increase capacity
            capacity *= 2;
            int* temp = (int*)realloc(pageReferences, sizeof(int) * capacity);
            if (temp == NULL) {
                printf("Failed to reallocate memory for page references.\n");
                free(pageReferences);
                return -1;
            }
            pageReferences = temp;
        }
        pageReferences[refCount++] = pageNumber;
    }

    // Initialize the memory manager with FIFO page replacement algorithm
    manager = MemoryManager_create(frameCount);
    if (manager == NULL) {
        printf("Failed to initialize the memory manager.\n");
        free(pageReferences);
        return -1;
    }

    // Simulate the page references
    MemoryManager_simulate(manager, pageReferences, refCount);

    // Cleanup
    MemoryManager_destroy(manager);
    free(pageReferences);

    return 0;
}
