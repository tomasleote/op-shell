// frame.h
#ifndef FRAME_H
#define FRAME_H

typedef struct Frame {
    int pageNumber;
} Frame;

// Constructor and destructor equivalents
Frame* Frame_create(int pageNumber);
void Frame_destroy(Frame* frame);

// Getter for the page number
int Frame_getPageNumber(Frame* frame);

#endif // FRAME_H
