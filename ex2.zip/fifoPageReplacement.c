// FIFOPageReplacement.c
#include "fifoPageReplacement.h"
#include <stdlib.h>
#include <stdio.h>

FIFOPageReplacement* FIFOPageReplacement_create(int frameCount) {
    FIFOPageReplacement* fifo = (FIFOPageReplacement*)malloc(sizeof(FIFOPageReplacement));
    if (fifo == NULL) {
        return NULL; // Failed to allocate memory
    }
    fifo->frames = (Frame**)malloc(sizeof(Frame*) * frameCount);
    for (int i = 0; i < frameCount; i++) {
        fifo->frames[i] = NULL; // Initialize all frames as empty
    }
    fifo->frameCount = frameCount;
    fifo->front = 0;
    fifo->rear = -1; // -1 indicates that the queue is empty
    fifo->pageFaults = 0;
    return fifo;
}

void FIFOPageReplacement_destroy(FIFOPageReplacement* fifo) {
    if (fifo != NULL) {
        for (int i = 0; i < fifo->frameCount; i++) {
            Frame_destroy(fifo->frames[i]); // Destroy each frame
        }
        free(fifo->frames); // Free the frame array
        free(fifo); // Free the fifo structure
    }
}

void FIFOPageReplacement_processPageReference(FIFOPageReplacement* fifo, int pageNumber) {
    // Check if the page is already in one of the frames
    for (int i = 0; i < fifo->frameCount; i++) {
        if (fifo->frames[i] != NULL && Frame_getPageNumber(fifo->frames[i]) == pageNumber) {
            return; // Page hit, no action needed
        }
    }

    // Page fault, replace the oldest page
    //printf("Page %d fault\n", pageNumber);
    fifo->pageFaults++;

    // Move front pointer if necessary
    if (fifo->frames[fifo->front] != NULL) {
        Frame_destroy(fifo->frames[fifo->front]); // Remove the oldest frame
    }

    // Insert new page at rear
    fifo->rear = (fifo->front + 1) % fifo->frameCount; // Circular queue logic
    fifo->frames[fifo->front] = Frame_create(pageNumber);
    fifo->front = (fifo->front + 1) % fifo->frameCount; // Move front to the next oldest frame
}

int FIFOPageReplacement_getPageFaults(FIFOPageReplacement* fifo) {
    return fifo->pageFaults;
}
