#ifndef FIFO_PAGE_REPLACEMENT_H
#define FIFO_PAGE_REPLACEMENT_H

#include "frame.h"

typedef struct {
    Frame** frames; // Array of pointers to Frame
    int frameCount;
    int front; // Points to the oldest frame
    int rear; // Points to the newest frame
    int pageFaults;
} FIFOPageReplacement;

// Constructor and destructor equivalents
FIFOPageReplacement* FIFOPageReplacement_create(int frameCount);
void FIFOPageReplacement_destroy(FIFOPageReplacement* fifo);

// Method to process a page reference
void FIFOPageReplacement_processPageReference(FIFOPageReplacement* fifo, int pageNumber);

// Method to get the total number of page faults
int FIFOPageReplacement_getPageFaults(FIFOPageReplacement* fifo);

#endif // FIFO_PAGE_REPLACEMENT_H
